<?php
/**
 * Handles all downloading, parsing and inserting of gzipped IDX listing
 * information
 *
 */
class IdxImporter
{
	const DATA_PATH = 'data/';
	const KEY				= 'ABQIAAAAQrALD1gkrDQBgZVKuJVSMxQRwfJhoVWgknqfmqOSaM5Mzma6ExR3J3-uu9XG9a4EZ93tqgTSqcygOA';
	const MAPS_HOST = 'maps.google.com';
	
	const LISTINGS_TABLE = 'Listings';
	
	private $listings = array(
		'commercial industrial',
		'lots lands farms',
		'multi-unit income',
		'residential rentals',
		'single family attached',
		'single family detached',
	);
	
	private $listings_meta = array(
		'pre'  => 'listings-',
		'post' => '.txt.gz',
	);
	
	private $pics_meta = array(
		'pre'  => 'pics-',
		'post' => '.tar',
	);
	
	private $replacements = array(
    '#' 			=> 'number',
    ' ' 			=> '_',
		'/' 			=> '_or_',
		'.' 			=> '',
		'$' 		  => 'money',
		'type' 	  => 'type_reserved',
		'area' 	  => 'area_reserved',
		'status'  => 'status_reserved',
		'range'   => 'range_reserved',
	);
	
	private $conn;
	
	private $db_conn;
	
	private $time;
	
	private $existing_geocodes;
	private $existing_mls_numbers;
	
	/**
	 * create a new instance and connect to the ftp server
	 */
	public function __construct(&$db_conn)
	{
		$this->db_conn = $db_conn;
		
		$this->time = microtime(true);
	}
	
	/**
	 * close the ftp connection
	 */
	public function __destruct()
	{
		if (!is_null($this->conn)) {
			ftp_close($this->conn);
		}
	}
	
	/**
	 * @return an instance for chaining
	 */
	static public function getInstance($db_conn)
	{
		return new IdxImporter($db_conn);
	}
	
	/**
	 * connect to the ftp server
	 */
	public function connect()
	{
		$this->conn  = ftp_connect('**********');
		$login = ftp_login($this->conn, '*********', '********'); ftp_pasv($this->conn, true);
		ftp_chdir($this->conn, 'idx');
		
		return $this;
	}
	
	/**
	 * spit out Doctrine YAML schema as html
	 * @return $this
	 */
	public function createYamlSchema()
	{ 
		$fields = array();
		foreach ($this->listings as $listing) {
				
			$file = gzopen(dirname(__FILE__) .'/../' .IdxImporter::DATA_PATH .$this->makeFilename($listing), 'r');
			$line = $this->replace(gzgets($file));
			
			//get the fields per listing
			$individual[$listing] = explode("\t", $line);
			
			foreach ($individual[$listing] as $key=>$value) {
				if (trim($value) != '') {
					$temp[$listing][$key] = $value;
				}
			}
			$individual = $temp;
			
			$fields = array_merge($fields, $individual[$listing]);
		}
		
		$fields = array_unique($fields);
		
		echo '
			Listings:<br>
			&nbsp;&nbsp;actAs:<br>
			&nbsp;&nbsp;&nbsp;&nbsp;Timestampable: { options: { onInsert: false } }<br>
			&nbsp;&nbsp;&nbsp;&nbsp;Geographical:  { latitude: { type: decimal(11), scale: 7 }, longitude: { type: decimal(11), scale: 7 } }<br>
			&nbsp;&nbsp;columns:<br>&nbsp;&nbsp;&nbsp;&nbsp;' .
			implode(': { type: string(255) }<br>&nbsp;&nbsp;&nbsp;&nbsp;', $fields)
			.': { type: string(255) }<br>'
			.'&nbsp;&nbsp;&nbsp;&nbsp;krb_listing: { type: boolean, default: 1 }<br>';
			
		return $this;
			
		//&nbsp;&nbsp;&nbsp;&nbsp;Geographical:  { options: { latitude: { type: decimal(4,7) }, longitude: { type: decimal(4,7) } } }<br>
	}
		
	/**
	 * get some basic performance metrics of this class
	 */
	public function debug($run = true, $whole_time = false)
	{
		if ($run) {
			echo 'Max memory used: ' .( (int) ( memory_get_peak_usage(true) / 100000) / 10 ) .'MB<br>';
			echo 'Time to execute: ' .( (int)(microtime(true) - $this->time) ).'s<br>';
		}
		
		if ($whole_time) {
			echo 'Time to execute (ms): ' .( (microtime(true) - $this->time) ).'s<br>';
		}
	}
	
	/**
	 * get rid of all listings to abide by IDX rules and regulations
	 * regarding total reload every 7 days.
	 */
	public function deleteAllListings()
	{
		$deleted = Doctrine_Query::create()
			->delete(IdxImporter::LISTINGS_TABLE .' l')
			->execute();
		
		echo $deleted .' listings deleted';
			
		return $deleted;
	}
	
	/**
	 * remove listings from the database that are not in the idx list anymore
	 */
	private function deleteOldListings(array $current_listings)
	{		
		$deleted = Doctrine_Query::create()
			->delete(IdxImporter::LISTINGS_TABLE .' l')
			->whereNotIn('l.mls_number', $current_listings)
			->execute();
		
		echo $deleted .' listings deleted';
			
		return $deleted;
	}	
	
	/**
	 * download all the listings based on the $listings array
	 */
	public function downloadListings($what = 'both')
	{
		set_time_limit(1200);
		
		foreach ($this->listings as $listing) {
			$file = $this->makeFilename($listing);
			
			if ($what == 'listings' || $what == 'both') {
				ftp_get($this->conn, dirname(__FILE__) .'/../'.IdxImporter::DATA_PATH .$file, $file, FTP_BINARY);
			}
			
			if ($what == 'pics' || $what == 'both') {
				foreach ($this->getPicsFiles('all -o') as $p) {
					$pic_file = $this->makeFilename($listing, false, $p);

					if (ftp_size($this->conn, $pic_file) != -1) {
						ftp_get($this->conn, dirname(__FILE__) .'/../'.IdxImporter::DATA_PATH .$pic_file, $pic_file, FTP_BINARY);
						echo $pic_file .' downloaded<br>';
					} else {
						//echo $pic_file .' not found<br>';
					}
				}
			}
			
		}
		
		return $this;
	}
	
	/**
	 * dump the database before doing any deleting
	 */
	public function dump()
	{ set_time_limit(360);
		//$dir = IdxImporter::DATA_PATH .date('mdy');
		Doctrine_Core::dumpData(dirname(__FILE__) .'/full.yml');
		//Doctrine_Core::dumpData($dir, true);
		return $this;
		$all = Doctrine_Query::create()
			->select('l.*')
			->from('Listings l')
			->execute(array(), Doctrine_Core::HYDRATE_SCALAR);
		
	//	print_r($all); die();	
			
		foreach($all as $one){
			print_r($one);
		}
		
		return $this;
	}
	
	/**
	 * geocode addresses using google maps. If addresses are more than 50 miles from
	 * Bridgeport or they weren't geocoded at all, then they are retried using only
	 * zip, state and country
	 *
	 * @return $this
	 */
	public function geocode($basic_address = false, $failed = array(), $recursive_count = 0, $limit = 500)
	{
		$flush_count = 0;
		
		$base_url = "http://" . IdxImporter::MAPS_HOST . "/maps/geo?output=xml" . "&key=" . IdxImporter::KEY;
		$delay = 0;
		
		$uncodeds = Doctrine_Core::getTable('Listings')->getUncoded($limit);
		
		//echo $uncodeds->count();
		//echo $uncodeds[0]->getPrettyAddress();
		//die();
		
		// Iterate through the rows, geocoding each address
		foreach ($uncodeds as $uncoded) {
			set_time_limit(72);
			
			$geocode_pending = true;
		
			while ($geocode_pending) {
				
				//try the most detailed address;
				if (!$basic_address) {
					$address = $uncoded->getPrettyAddress();
				
				//it already failed once so we use zip state country
				} elseif ($basic_address && in_array($uncoded->id, $failed)) {
					$address = $uncoded->state.' '.$uncoded->zip.' USA';
					
					unset($failed[array_search($uncoded->id, $failed)]);
				
				//what the hell!?
				}else{
					echo $uncoded->mls_number .' not hit';
				}
				
				//make the geocode request and load response
				$request_url = $base_url . '&q=' . urlencode($address);
				$xml = simplexml_load_file($request_url) or die('url not loading');
				$status = $xml->Response->Status->code;
				
				//successful geocode
				if (strcmp($status, '200') == 0
				 && $correct_state = in_array($xml->Response->Placemark->AddressDetails->Country->AdministrativeArea->AdministrativeAreaName[0], array('WV', 'PA'))) {
					
					//finished geocoding so we can do a new address.
					$geocode_pending = false;
					
					//get the lat/lng from the response
					$coordinates = $xml->Response->Placemark->Point->coordinates;
					$coordinatesSplit = explode(',', $coordinates);
					
					//format: Longitude, Latitude, Altitude
					$lat = $coordinatesSplit[1];
					$lng = $coordinatesSplit[0];

					//get the distance of the geocodee from bridgeport
					$distance_from_bridgeport = (
						ACOS(SIN(39.3011575 * PI() / 180) * SIN($lat * PI() / 180)
				+ 	COS(39.3011575 * PI() / 180) * COS($lat * PI() / 180)
				* 	COS((-80.2098219 - $lng) * PI() / 180)) * 180 / PI() * 60 *1.1515
					);
					
					//if its further than 60 miles from Bridgeport and its the detailed,
					//then the geocode probably found the wrong place.
					if ($distance_from_bridgeport > 60 && !$basic_address) {
						echo $address .' is too far'.$distance_from_bridgeport.'<br>';
						$failed[] = $uncoded->id;
					} else {
						$uncoded->latitude  = $lat;
						$uncoded->longitude = $lng;
					}
				
				// sent geocodes too fast
				} else if (strcmp($status, '620') == 0) {
					$delay += 100000;
				
				// failure to geocode
				} else if (strcmp($status, '602') == 0 || !$correct_state) {
					$failed[] = $uncoded->id;
					$geocode_pending = false;
					echo $uncoded .'failed to geocode<br>';
				
				//something else bad happened
				} else {
					$geocode_pending = false;
					echo 'Address ' .$address . ' failed to geocode.';
					echo 'Received status ' . $status . "\n<br>";
				}
				
				usleep($delay);
			}
			
			//save every 100 to be safe/memory-conscious
			if(++$flush_count % 100 === 0) {
				$this->db_conn->flush();
			}
		}
		
		//save the rest
		$this->db_conn->flush();
		
		//rerun listings that weren't geocoded or were too far
		if (!empty($failed) && $recursive_count < 1) {
			$this->geocode(true, $failed, ++$recursive_count);
		}
		
		return $this;

	}
	
	/**
	 * get the list of existing mls id's for the given table
	 * @return 1d array of existing mls id numbers
	 */
	public function getExistingIds()
	{ 
		$existing_fetched = Doctrine_Query::create()
			->select('mls_number')
			->from(IdxImporter::LISTINGS_TABLE)
			->fetchArray();	
		
		$existing = array();	
		foreach ($existing_fetched as $e) {
			$existing[] = $e['mls_number'];
		}
			
		//print_r($existing); die();
			
		return $existing;
	}
	
	public function getExistingGeocodes()
	{
		$geos = Doctrine_Query::create()
    ->select('mls_number, latitude, longitude')
    ->from('Listings l')
    ->execute(array(), Doctrine_Core::HYDRATE_ARRAY);
    

		foreach($geos as $g) {
			$m[$g['mls_number']]['latitude']  = $g['latitude'];
			$m[$g['mls_number']]['longitude'] = $g['longitude'];
		}
		
		unset($geos);
		
		return $m;
	}
	
	public function getPicsFiles($day)
	{
		if ($day == 'recent') {
			$days = array(1);
		} elseif ($day == 'all' || $day == 'all -o') {
			$days = array();
			
			for ($i = 1; $i < 10; $i++) {
				$days[] = $i;
			}
			
			if ($day == 'all -o') {
				array_pop($days);
			}
			
		} elseif (is_numeric($day)) {
			$days = array($day);
		}
		
		return $days;
	}
	
	/**
	 * insert new listings for the listing file
	 *
	 * @return number of listings inserted
	 */
	public function insertListing($table)
	{
		set_time_limit(450);
		
		$table_name = IdxImporter::LISTINGS_TABLE; //strtoupper($this->replace($table));
		
		$file = gzopen(dirname(__FILE__) .'/../' .IdxImporter::DATA_PATH .$this->makeFilename($table), 'r');
		$line = $this->replace(gzgets($file));
		
		$fields = explode("\t", $line);
		
		$not_inserted =
		$object_count = 0;
		
		$listings = new Doctrine_Collection($table_name);
		
		while ($line = gzgets($file)):
			$field_position = 0;
			
			$listing = explode("\t", $line);
			
			$current_listings[] = $listing[0];
			
			//if (1==1 || !in_array($listing[0], $this->existing_mls_numbers)) {
				
			$listings[$object_count] = new $table_name();
			foreach ($fields as $listing_field) {
				
				if (trim($listing_field) != '') {
					$listings[$object_count]->$listing_field = $listing[$field_position];
				}
				
				$field_position++;
			}
			
			if (isset($this->existing_geocodes[$listings[$object_count]->mls_number])) {
				$listings[$object_count]->latitude  = $this->existing_geocodes[$listings[$object_count]->mls_number]['latitude'];
				$listings[$object_count]->longitude = $this->existing_geocodes[$listings[$object_count]->mls_number]['longitude'];
			}
			
			//$g = new Doctrine_Collection()
				
			//$listings[$object_count]->save();
			//$listings[$object_count]->free();
			
				
			if(++$object_count % 100 === 0) {
				$listings->save();
				$listings->free(true);
				$listings = new Doctrine_Collection($table_name);
			}
			
	
				
				
			//}else{ $not_inserted++; }
		endwhile;
		
		gzclose($file);
		
		$this->db_conn->flush();
		
		return array(
			'object_count' 		 => $object_count,
			'current_listings' => $current_listings
		);
	}
	
	/**
	 * iterate through the listings, retreiving existing ids and inserting new
	 *
	 * @return $this
	 */
	public function insertListings()
	{
		
		//$this->existing_mls_numbers = $this->getExistingIds();
		$this->existing_geocodes 		= $this->getExistingGeocodes();
		
		$this->deleteAllListings();
		
		$current_listings = array();
		
		foreach ($this->listings as $listing) {
			$inserted = $this->insertListing($listing);
			echo "New Listings for $listing inserted: " .$inserted['object_count'] .'<br>';
			
			$current_listings = array_merge($current_listings, $inserted['current_listings']);
		}
				
		$this->setKrbListings();
		
		return $this;
	}
	
	public function updateListings()
	{
		
	}
	
	/**
	 * constructs the filename based on the $listings_meta array
	 */
	private function makeFilename($file, $listings = true, $days_ago = 1)
	{
		if ($listings) {
			return $this->listings_meta['pre'] .$file .$this->listings_meta['post'];
		} else{
			if ($days_ago == 9) {
				$date = 'old';
			} else {
				$date = date('Ymd', strtotime( '-' .$days_ago .' days', strtotime( date('Ymd') ) ) );
			}
			
			$filename = $this->pics_meta['pre'] .$file .'-' .$date .$this->pics_meta['post'];

			return $filename;
		}
	}
	
	/**
	 * untar the pictures for all/given listing for most recent/specific/all days
	 */
	public function untarPics($listing = null, $day = 'recent')
	{
		set_time_limit(360);
		
		if (is_null($listing) || $listing == 'all') {
			$listing = $this->listings;
		} else {
			$listing = array($listing);
		}
		
		$days = $this->getPicsFiles($day);
		
		foreach ($listing as $l) {
			foreach ($days as $d) {
				$file = $this->makeFilename($l, false, $d);

				if (file_exists(IdxImporter::DATA_PATH .$file)) {
					//echo $file .' untarred<br>';
					
						//exec('"c:\program files\7-zip\7z.exe" -o"c:\wamp\www\krbproperties\idx\data\pics" e "c:\wamp\www\krbproperties\idx\data\\'  .$file .'" -y');
						
					$t = new tar();
					$t->openTar(IdxImporter::DATA_PATH .$file);
					
					foreach($t->files as $p){
						$f = fopen(IdxImporter::DATA_PATH .'pics/' .$p['name'], 'w');
						fwrite($f, $p['file']);

					}
					fclose($f);	unlink(IdxImporter::DATA_PATH .$file);
				} else{
					//echo $file .' does not exist<br>';
				}
			}
		}
		
		return $this;
	}
	
	/**
	 * replace special characters on listing txt.gz to conform to db conventions
	 * based on the $replacements array
	 */
	public function replace($line)
	{
		foreach ($this->replacements as $original => $replacement) {
			$line = str_replace($original, $replacement, strtolower($line));
		}
		
		return $line;
	}
	
	/**
	 * set the krb_listing field = 1 for all krb prop listings
	 */
	public function setKrbListings()
	{
		$q = Doctrine_Query::create()
			->update('Listings')
			->set('krb_listing', 1)
			->where  ('listing_office_1_name LIKE ?', 'krb%')
			->orWhere('listing_office_2_name LIKE ?', 'krb%')
			->execute();
			
		echo $q .' listings from KRB Properties<br>';
	}
	
	
}